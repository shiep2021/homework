import tkinter as tk
from PIL import ImageTk, Image
 
root = tk.Tk()
#背景

canvas = tk.Canvas(root, width=565,height=376,bd=0, highlightthickness=0)
imgpath = 'cat.gif'
img = Image.open(imgpath)
photo = ImageTk.PhotoImage(img)
 
canvas.create_image(565,200, image=photo)
canvas.pack()
#entry=tk.Entry(root,insertbackground='blue', highlightthickness =2)
#entry.pack()
 
 
root.mainloop()


