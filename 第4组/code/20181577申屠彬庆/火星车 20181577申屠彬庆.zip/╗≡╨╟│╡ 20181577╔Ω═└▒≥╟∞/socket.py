import vtk
import datetime
import cv2

i=0
j=0
k=0
h=0
z=0
p=0
f=0
g=0
j=0
class KeyPressInteractorStyle(vtk.vtkInteractorStyleTrackballCamera):

    def __init__(self, parent=None):
        self.parent = vtk.vtkRenderWindowInteractor()
        if (parent is not None):
            self.parent = parent

        self.AddObserver("KeyPressEvent", self.keyPress)

    def keyPress(self, obj, event):
        global i,j,k,z,h,p,f,g,h
        key = self.parent.GetKeySym()
        if key == 'l':  #自动化
            for p in range(130):
                actor.SetPosition(i,j,k)
                k=k+0.5
                renWin.Render()
            for f in range(60):
                actor.RotateY(z)
                z=z-0.05
                renWin.Render()
            for g in range(570):
                actor.SetPosition(i,j,k)
                i=i-0.5
                renWin.Render()
            ren.AddActor(actor3)
            for j in range(120):
                h=h-0.5
                actor3.SetPosition(0,0,h)
                renWin.Render()
        if key == 'w': #前后
            actor.SetPosition(i,j,k)
            i=i-0.5
            renWin.Render()
        if key == 's':
            actor.SetPosition(i,j,k)
            k=k+0.5
            renWin.Render()
        if key == 'd':  #左右
            actor.SetPosition(i,j,k)
            j=j+0.5
            renWin.Render()
        if key == 'f':
            actor.RotateY(z)
            z=z-0.05
            renWin.Render()
        if key == 'g':
            actor.RotateY(z)
            z=z-0.5
            renWin.Render()
        if key == 'Down':  #小车降落
            h=h-0.5
            actor3.SetPosition(0,0,h)
            renWin.Render()
        if key == 'Up':  #小车出现
            #ren.AddActor(actor3)
            close_window(iren)



def close_window(iren):
    render_window = iren.GetRenderWindow()
    render_window.Finalize()
    iren.TerminateApp()


reader = vtk.vtkSTLReader()
reader.SetFileName("rocket.stl")
mapper = vtk.vtkPolyDataMapper()
mapper.SetInputConnection(reader.GetOutputPort())
actor = vtk.vtkActor()
actor.SetMapper(mapper)


reader1 = vtk.vtkSTLReader()
reader1.SetFileName("earth.stl")
mapper1 = vtk.vtkPolyDataMapper()
mapper1.SetInputConnection(reader1.GetOutputPort())
actor1 = vtk.vtkActor()
actor1.SetMapper(mapper1)


reader2 = vtk.vtkSTLReader()
reader2.SetFileName("mars.stl")
mapper2 = vtk.vtkPolyDataMapper()
mapper2.SetInputConnection(reader2.GetOutputPort())
actor2 = vtk.vtkActor()
actor2.SetMapper(mapper2)

reader3 = vtk.vtkSTLReader()
reader3.SetFileName("car.stl")
mapper3 = vtk.vtkPolyDataMapper()
mapper3.SetInputConnection(reader3.GetOutputPort())
actor3 = vtk.vtkActor()
actor3.SetMapper(mapper3)
# 修改actor初始颜色
actor.GetProperty().SetColor(1.0, 1.0, 1.0)
#actor1.GetProperty().SetColor(0, 255, 1.0)
actor2.GetProperty().SetColor(255, 1.0, 1.0)
#actor3.GetProperty().SetColor(255, 1.0, 1.0)
actor.SetOrigin(actor.GetCenter())
# 修改actor初始状态旋转角度
ren = vtk.vtkRenderer()
renWin = vtk.vtkRenderWindow()
renWin.AddRenderer(ren)
iren = vtk.vtkRenderWindowInteractor()
iren.SetRenderWindow(renWin)

iren.SetInteractorStyle(KeyPressInteractorStyle(parent=iren))
print("actor center:",actor1.GetCenter())
ren.AddActor(actor)
ren.AddActor(actor1)
ren.AddActor(actor2)

# 修改背景颜色
ren.SetBackground(0.1, 0.2, 0.3)
# 修改窗口大小
renWin.SetSize(300, 300)

iren.Initialize()

ren.ResetCamera()
ren.GetActiveCamera().Zoom(1.5)
renWin.Render()

iren.Start()

 

    