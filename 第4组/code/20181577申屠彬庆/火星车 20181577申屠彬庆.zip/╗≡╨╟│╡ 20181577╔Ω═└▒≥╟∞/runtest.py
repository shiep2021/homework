from tkinter.constants import SEL_FIRST, W
import vtk
import math
import datetime
import cv2
import time
import sys
import numpy as np
import tkinter
i=0
j=0
k=0
b=0
n=0
m=0
h=0
z=0
p=0
f=0
g=0
j=0
k=0
l=0

distance = 0
distance1 = 0
anglesign = 0
angle = 0
top = tkinter.Tk()
top.title("tk")
img=np.zeros((600,600,3),np.uint8)
img[:]=[100,5,100]

def close_window(iren):
    render_window = iren.GetRenderWindow()
    render_window.Finalize()
    iren.TerminateApp()

def stbq():
    class KeyPressInteractorStyle(vtk.vtkInteractorStyleTrackballCamera):

        def __init__(self, parent=None):
            self.parent = vtk.vtkRenderWindowInteractor()
            if (parent is not None):
                self.parent = parent

            self.AddObserver("KeyPressEvent", self.keyPress)
            self.AddObserver("KeyPressEvent", self.w)
        def w(self):
            global b,n,m,z,h,p,f,g,h,j,k,l
            date = time.strftime('%Y-%m-%d' ,time.localtime())
            time1 = time.strftime('%H:%M:%S' ,time.localtime())
            for k in range(300):
                actor.SetPosition(b,n,m)
                m=m+0.05
                renWin.Render()
                #print(time.strftime(' %Y-%m-%d %H:%M:%S' ,time.localtime()))
                file = open("%s.txt" %date,'a')
                #file.write('123 \n')
                coo = str(actor.GetCenter())
                time2 = time1
                str(time2) 
                file.write(time2)
                file.write('  ')
                #file.write('123 \n')
                file.write("Real time coordinates of rocket:")
                file.write(coo)
                file.write('  \n')
                file.close() 
            for p in range(600):
                actor.RotateY(z)
                z=z-0.0005
                actor.SetPosition(b,n,m)
                m=m+0.075
                actor.SetPosition(b,n,m)
                b=b-0.25
                renWin.Render()
                #print(time.strftime(' %Y-%m-%d %H:%M:%S' ,time.localtime()))
                file = open("%s.txt" %date,'a')
                #file.write('123 \n')
                coo = str(actor.GetCenter())
                time2 = time1
                str(time2) 
                file.write(time2)
                file.write('  ')
                #file.write('123 \n')
                file.write("Real time coordinates of rocket:")
                file.write(coo)
                file.write('  \n')
                file.close()
            for g in range(600):
                actor.SetPosition(b,n,m)
                b=b-0.25
                renWin.Render()
                file = open("%s.txt" %date,'a')
                #file.write('123 \n')
                coo = str(actor.GetCenter())
                time2 = time1
                str(time2) 
                file.write(time2)
                file.write('  ')
                #file.write('123 \n')
                file.write("Real time coordinates of rocket:")
                file.write(coo)
                file.write('  \n')
                file.close()
            for j in range(240):
                h=h-0.25
                actor3.SetPosition(0,0,h)
                renWin.Render()
                file = open("%s.txt" %date,'a')
            #file.write('123 \n')
                coo1 = str(actor3.GetCenter())
                time2 = time1
                str(time2) 
                file.write(time2)
                file.write('  ')
                #file.write('123 \n')
                file.write("Real time coordinate of car:")
                file.write(coo1)
                file.write('  \n')
                file.close()
                ren.AddActor(actor3)
            close_window(iren)
            swf()            
        def keyPress(self, obj, event):
            global b,n,m,z,h,p,f,g,h,j,k,l
            key = self.parent.GetKeySym()
            if key == 'l':  #自动化
                date = time.strftime('%Y-%m-%d' ,time.localtime())
                time1 = time.strftime('%H:%M:%S' ,time.localtime())
                for k in range(300):
                    actor.SetPosition(b,n,m)
                    m=m+0.05
                    renWin.Render()
                    #print(time.strftime(' %Y-%m-%d %H:%M:%S' ,time.localtime()))
                    file = open("%s.txt" %date,'a')
                    #file.write('123 \n')
                    coo = str(actor.GetCenter())
                    time2 = time1
                    str(time2) 
                    file.write(time2)
                    file.write('  ')
                    #file.write('123 \n')
                    file.write("Real time coordinates of rocket:")
                    file.write(coo)
                    file.write('  \n')
                    file.close() 
                for p in range(600):
                    actor.RotateY(z)
                    z=z-0.0005
                    actor.SetPosition(b,n,m)
                    m=m+0.075
                    actor.SetPosition(b,n,m)
                    b=b-0.25
                    renWin.Render()
                    #print(time.strftime(' %Y-%m-%d %H:%M:%S' ,time.localtime()))
                    file = open("%s.txt" %date,'a')
                    #file.write('123 \n')
                    coo = str(actor.GetCenter())
                    time2 = time1
                    str(time2) 
                    file.write(time2)
                    file.write('  ')
                    #file.write('123 \n')
                    file.write("Real time coordinates of rocket:")
                    file.write(coo)
                    file.write('  \n')
                    file.close()
                for g in range(600):
                    actor.SetPosition(b,n,m)
                    b=b-0.25
                    renWin.Render()
                    file = open("%s.txt" %date,'a')
                    #file.write('123 \n')
                    coo = str(actor.GetCenter())
                    time2 = time1
                    str(time2) 
                    file.write(time2)
                    file.write('  ')
                    #file.write('123 \n')
                    file.write("Real time coordinates of rocket:")
                    file.write(coo)
                    file.write('  \n')
                    file.close()
                for j in range(240):
                    h=h-0.25
                    actor3.SetPosition(0,0,h)
                    renWin.Render()
                    file = open("%s.txt" %date,'a')
                #file.write('123 \n')
                    coo1 = str(actor3.GetCenter())
                    time2 = time1
                    str(time2) 
                    file.write(time2)
                    file.write('  ')
                    #file.write('123 \n')
                    file.write("Real time coordinate of car:")
                    file.write(coo1)
                    file.write('  \n')
                    file.close()
                    ren.AddActor(actor3)
                close_window(iren)
                swf()
            if key == 'w': #前后
                actor.SetPosition(b,n,m)
                b=b-0.5
                renWin.Render()
            if key == 's':
                actor.SetPosition(b,n,m)
                m=m+0.5
                renWin.Render()
            if key == 'd':  #左右
                actor.SetPosition(b,n,m)
                n=n+0.5
                renWin.Render()
            if key == 'f':
                actor.RotateY(z)
                z=z-0.05
                renWin.Render()
            if key == 'g':
                actor.RotateY(z)
                z=z-0.5
                renWin.Render()
            if key == 'Down':  #小车降落
                h=h-0.5
                actor3.SetPosition(0,0,h)
                renWin.Render()
            if key == 'Up':  
                ren.AddActor(actor3)

            if key == 'r':
            #txtname = datetime.datetime.now()
            #print('txtname = ',txtname)
                #print(time.strftime(' %Y-%m-%d %H:%M:%S' ,time.localtime()))
                file = open("%s.txt" %date,'a')
                #file.write('123 \n')
                coo = str(actor.GetCenter())
                time2 = time1
                str(time2) 
                file.write(time2)
                file.write('  ')
                #file.write('123 \n')
                file.write("火箭坐标：")
                file.write(coo)
                file.write('  \n')
                file.close()
        

    print(time.strftime(' %Y-%m-%d %H:%M:%S' ,time.localtime()))
    reader = vtk.vtkSTLReader()
    reader.SetFileName("rocket.stl")
    mapper = vtk.vtkPolyDataMapper()
    mapper.SetInputConnection(reader.GetOutputPort())
    actor = vtk.vtkActor()
    actor.SetMapper(mapper)


    reader1 = vtk.vtkSTLReader()
    reader1.SetFileName("earth.stl")
    mapper1 = vtk.vtkPolyDataMapper()
    mapper1.SetInputConnection(reader1.GetOutputPort())
    actor1 = vtk.vtkActor()
    actor1.SetMapper(mapper1)


    reader2 = vtk.vtkSTLReader()
    reader2.SetFileName("mars.stl")
    mapper2 = vtk.vtkPolyDataMapper()
    mapper2.SetInputConnection(reader2.GetOutputPort())
    actor2 = vtk.vtkActor()
    actor2.SetMapper(mapper2)

    reader3 = vtk.vtkSTLReader()
    reader3.SetFileName("car.stl")
    mapper3 = vtk.vtkPolyDataMapper()
    mapper3.SetInputConnection(reader3.GetOutputPort())
    actor3 = vtk.vtkActor()
    actor3.SetMapper(mapper3)
    # 修改actor初始颜色
    actor.GetProperty().SetColor(1.0, 1.0, 1.0)
    actor1.GetProperty().SetColor(0, 255, 1.0)
    actor2.GetProperty().SetColor(255, 1.0, 1.0)
    #actor3.GetProperty().SetColor(255, 1.0, 1.0)
    actor.SetOrigin(actor.GetCenter())
    # 修改actor初始状态旋转角度
    ren = vtk.vtkRenderer()
    renWin = vtk.vtkRenderWindow()
    renWin.AddRenderer(ren)
    iren = vtk.vtkRenderWindowInteractor()
    iren.SetRenderWindow(renWin)

    iren.SetInteractorStyle(KeyPressInteractorStyle(parent=iren))
    print("actor center:",actor1.GetCenter())
    ren.AddActor(actor)
    ren.AddActor(actor1)
    ren.AddActor(actor2)

    # 修改背景颜色
    ren.SetBackground(0.1, 0.2, 0.3)
    # 修改窗口大小
    renWin.SetSize(300, 300)

    #iren.Initialize()

    ren.ResetCamera()
    ren.GetActiveCamera().Zoom(1.5)
    #renWin.Render()

    #iren.Start()
    shy = KeyPressInteractorStyle()
    def q():
        renWin.Render() 
    btn=tkinter.Button(top,text="发射",command=shy.w)
    btn.place(x=90,y=155)
    btn=tkinter.Button(top,text="启动",command=q)
    btn.place(x=60,y=155)      
    tkinter.Label(top, text='火箭发射', font=('Arial',8)).place(x=20,y=0)
    top.mainloop()
def swf():
    stop_threads = False
    class KeyPressInteractorStyle(vtk.vtkInteractorStyleTrackballCamera):
    
        def __init__(self,parent=None):
            self.parent = vtk.vtkRenderWindowInteractor()
            if(parent is not None):
                self.parent = parent
    
            self.AddObserver("KeyPressEvent",self.keyPress)
    
        def keyPress(self,obj,event):
            key = self.parent.GetKeySym()
            speed=0
            global i
            global j
            global anglesign
            global angle
            global distance
            global distance1

            #print('i=',i)
            #print('j=',j)

            if key == 'Up':
                #前进
                #轮子转速
                actor2.RotateY(-8)
                actor3.RotateY(-8)
                #车子移动
                assembly1.SetPosition(i,j,0)
                distance = distance + 1
                i = i - abs(distance) * abs(math.cos(angle))
                if anglesign > 0 :
                    j = j - abs(distance) * abs(math.sin(angle))
                if anglesign < 0 :
                    j = j + abs(distance) * abs(math.sin(angle))
                #assembly1.AddPosition(i,j,0)
                #i = i - 1 
                renWin.Render()

            if key == 'Down':
                #后退
                #轮子转速
                actor2.RotateY(8)
                actor3.RotateY(8)           
                #车子移动
                assembly1.SetPosition(i,j,0)
                distance1 = distance1 - 1
                i = i + abs(distance1) * abs(math.cos(angle))
                if anglesign > 0:
                    j = j + abs(distance1) * abs(math.sin(angle))
                if anglesign < 0:
                    j = j - abs(distance1) * abs(math.sin(angle))
                #i = i + 1 
                renWin.Render()

            if key == 'Left':
                #左转
                #轮子转速
                actor2.RotateY(8)
                actor3.RotateY(2)
                #车子移动
                #assembly1.SetPosition(i,j,0)
                #j = j - 1
                #车子旋转
                assembly1.RotateZ(0.5)
                anglesign = anglesign + 1
                angle = anglesign * 0.5
                print('anglesign=',anglesign)
                print('angle=',angle)
                #print(math.sin(angle))
                #assembly1.RotateWXYZ(0.5,0,0,1)
                renWin.Render()

            if key == 'Right':
                #右转
                #轮子转速
                actor2.RotateY(2)
                actor3.RotateY(8)
                #车子移动
                #assembly1.SetPosition(i,j,0)
                #j = j + 1
                #车子旋转
                assembly1.RotateZ(-0.5)
                anglesign = anglesign - 1
                angle = anglesign * 0.5
                print('anglesign=',anglesign)
                print('angle=',angle)
                renWin.Render()
            

            
    reader1 = vtk.vtkSTLReader()
    reader1.SetFileName("carbody.stl")
    reader2 = vtk.vtkSTLReader()
    reader2.SetFileName("leftwheel.stl")
    reader3 = vtk.vtkSTLReader()
    reader3.SetFileName("rightwheel.stl")
    reader4 = vtk.vtkSTLReader()
    reader4.SetFileName("wheel-spindle.stl")
    reader5 = vtk.vtkSTLReader()
    reader5.SetFileName("camera.stl")
    reader6 = vtk.vtkSTLReader()
    reader6.SetFileName("camera-spindle.stl")
    reader7 = vtk.vtkSTLReader()
    reader7.SetFileName("sign1.stl")

    mapper1 = vtk.vtkPolyDataMapper()
    mapper1.SetInputConnection(reader1.GetOutputPort())
    mapper2 = vtk.vtkPolyDataMapper()
    mapper2.SetInputConnection(reader2.GetOutputPort())
    mapper3 = vtk.vtkPolyDataMapper()
    mapper3.SetInputConnection(reader3.GetOutputPort())
    mapper4 = vtk.vtkPolyDataMapper()
    mapper4.SetInputConnection(reader4.GetOutputPort())
    mapper5 = vtk.vtkPolyDataMapper()
    mapper5.SetInputConnection(reader5.GetOutputPort())
    mapper6 = vtk.vtkPolyDataMapper()
    mapper6.SetInputConnection(reader6.GetOutputPort())
    mapper7 = vtk.vtkPolyDataMapper()
    mapper7.SetInputConnection(reader7.GetOutputPort())

    actor1 = vtk.vtkActor()
    actor1.SetMapper(mapper1)
    actor2 = vtk.vtkActor()
    actor2.SetMapper(mapper2)
    actor3 = vtk.vtkActor()
    actor3.SetMapper(mapper3)
    actor4 = vtk.vtkActor()
    actor4.SetMapper(mapper4)
    actor5 = vtk.vtkActor()
    actor5.SetMapper(mapper5)
    actor6 = vtk.vtkActor()
    actor6.SetMapper(mapper6)
    actor7 = vtk.vtkActor()
    actor7.SetMapper(mapper7)

    assembly1 = vtk.vtkAssembly()
    assembly1.AddPart(actor1)
    assembly1.AddPart(actor2)
    assembly1.AddPart(actor3)
    assembly1.AddPart(actor4)
    assembly1.AddPart(actor5)
    assembly1.AddPart(actor6)
    
    ren = vtk.vtkRenderer()
    renWin = vtk.vtkRenderWindow()
    renWin.AddRenderer(ren)
    iren = vtk.vtkRenderWindowInteractor()
    iren.SetRenderWindow(renWin)
    iren.SetInteractorStyle(KeyPressInteractorStyle(parent = iren))


    #ren.AddActor(actor)
    '''
    ren.AddActor(actor1)
    ren.AddActor(actor2)
    ren.AddActor(actor3)
    ren.AddActor(actor4)
    ren.AddActor(actor5)
    ren.AddActor(actor6)
    ren.AddActor(actor7)
    '''
    ren.AddActor(assembly1)
    #ren.AddActor(axes)

    actor1.SetOrigin(actor1.GetCenter())
    actor2.SetOrigin(actor2.GetCenter())
    actor3.SetOrigin(actor3.GetCenter())
    assembly1.SetOrigin(actor1.GetCenter())

    #修改背景颜色
    ren.SetBackground(0.1, 0.2, 0.3)
    #修改窗口大小
    #renWin.SetSize(, )
    
    iren.Initialize()
    
    ren.ResetCamera()
    ren.GetActiveCamera().Zoom(1.5)
    renWin.Render()
    
    iren.Start()

if __name__ == '__main__':
    stbq()