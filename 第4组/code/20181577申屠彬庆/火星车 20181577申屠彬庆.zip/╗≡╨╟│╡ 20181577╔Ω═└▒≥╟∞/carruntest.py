from typing import MutableSet
import vtk
import math
import sys
import os
import sys
import numpy as np
import tkinter
import time
i = 0
j = 0
m = 0
distance = 0
distance1 = 0
anglesign = 0
angle = 0

stop_threads = False
top = tkinter.Tk()
top.title("tk")
img=np.zeros((600,600,3),np.uint8)
img[:]=[100,5,100]
date = time.strftime('%Y-%m-%d' ,time.localtime())
time1 = time.strftime('%H:%M:%S' ,time.localtime())

class KeyPressInteractorStyle(vtk.vtkInteractorStyleTrackballCamera):
 
    def __init__(self,parent=None):
        self.parent = vtk.vtkRenderWindowInteractor()
        if(parent is not None):
            self.parent = parent
 
        self.AddObserver("KeyPressEvent",self.keyPress)

    def keyPress(self,obj,event):
        key = self.parent.GetKeySym()
        speed=0
        global i
        global j,m
        global anglesign
        global angle
        global distance
        global distance1

        #print('i=',i)
        #print('j=',j)
    
        if key == 'Up':
            #前进
            #轮子转速
            actor2.RotateY(-8)
            actor3.RotateY(-8)
            #车子移动
            assembly1.SetPosition(i,j,0)
            distance = distance + 1
            i = float(i - float(abs(distance) * abs(math.cos(angle))))
            if anglesign > 0 :
                j = float(j - float(abs(distance) * abs(math.sin(angle))))
            if anglesign < 0 :
                j = j + abs(distance) * abs(math.sin(angle))
            #assembly1.AddPosition(i,j,0)
            #i = i - 1 
            renWin.Render()

        if key == 'Down':
            #后退
            #轮子转速
            actor2.RotateY(8)
            actor3.RotateY(8)           
            #车子移动
            assembly1.SetPosition(i,j,0)
            distance1 = distance1 - 1
            i = i + abs(distance1) * abs(math.cos(angle))
            if anglesign > 0:
                j = j + abs(distance1) * abs(math.sin(angle))
            if anglesign < 0:
                j = j - abs(distance1) * abs(math.sin(angle))
            #i = i + 1 
            renWin.Render()

        if key == 'Left':
            #左转
            #轮子转速
            actor2.RotateY(8)
            actor3.RotateY(2)
            #车子移动
            #assembly1.SetPosition(i,j,0)
            #j = j - 1
            #车子旋转
            assembly1.RotateZ(0.5)
            anglesign = anglesign + 1
            angle = anglesign * 0.5
            print('anglesign=',anglesign)
            print('angle=',angle)
            #print(math.sin(angle))
            #assembly1.RotateWXYZ(0.5,0,0,1)
            renWin.Render()

        if key == 'Right':
            #右转
            #轮子转速
            actor2.RotateY(2)
            actor3.RotateY(8)
            #车子移动
            #assembly1.SetPosition(i,j,0)
            #j = j + 1
            #车子旋转
            assembly1.RotateZ(-0.5)
            anglesign = anglesign - 1
            angle = anglesign * 0.5
            print('anglesign=',anglesign)
            print('angle=',angle)
            renWin.Render()
        if key == 'r':
            #txtname = datetime.datetime.now()
            #print('txtname = ',txtname)
            print(time.strftime(' %Y-%m-%d %H:%M:%S' ,time.localtime()))
            file = open("%s.txt" %date,'a')
            #file.write('123 \n')
            coo = str(assembly1.GetCenter())
            time2 = time1
            str(time2) 
            file.write(time2)
            file.write('  ')
            #file.write('123 \n')
            file.write(coo)
            file.write('  \n')
            file.close()

     
reader1 = vtk.vtkSTLReader()
reader1.SetFileName("carbody.stl")
reader2 = vtk.vtkSTLReader()
reader2.SetFileName("leftwheel.stl")
reader3 = vtk.vtkSTLReader()
reader3.SetFileName("rightwheel.stl")
reader4 = vtk.vtkSTLReader()
reader4.SetFileName("wheel-spindle.stl")
reader5 = vtk.vtkSTLReader()
reader5.SetFileName("camera.stl")
reader6 = vtk.vtkSTLReader()
reader6.SetFileName("camera-spindle.stl")
reader7 = vtk.vtkSTLReader()
reader7.SetFileName("sign1.stl")

mapper1 = vtk.vtkPolyDataMapper()
mapper1.SetInputConnection(reader1.GetOutputPort())
mapper2 = vtk.vtkPolyDataMapper()
mapper2.SetInputConnection(reader2.GetOutputPort())
mapper3 = vtk.vtkPolyDataMapper()
mapper3.SetInputConnection(reader3.GetOutputPort())
mapper4 = vtk.vtkPolyDataMapper()
mapper4.SetInputConnection(reader4.GetOutputPort())
mapper5 = vtk.vtkPolyDataMapper()
mapper5.SetInputConnection(reader5.GetOutputPort())
mapper6 = vtk.vtkPolyDataMapper()
mapper6.SetInputConnection(reader6.GetOutputPort())
mapper7 = vtk.vtkPolyDataMapper()
mapper7.SetInputConnection(reader7.GetOutputPort())

actor1 = vtk.vtkActor()
actor1.SetMapper(mapper1)
actor2 = vtk.vtkActor()
actor2.SetMapper(mapper2)
actor3 = vtk.vtkActor()
actor3.SetMapper(mapper3)
actor4 = vtk.vtkActor()
actor4.SetMapper(mapper4)
actor5 = vtk.vtkActor()
actor5.SetMapper(mapper5)
actor6 = vtk.vtkActor()
actor6.SetMapper(mapper6)
actor7 = vtk.vtkActor()
actor7.SetMapper(mapper7)

assembly1 = vtk.vtkAssembly()
assembly1.AddPart(actor1)
assembly1.AddPart(actor2)
assembly1.AddPart(actor3)
assembly1.AddPart(actor4)
assembly1.AddPart(actor5)
assembly1.AddPart(actor6)
 
ren = vtk.vtkRenderer()
renWin = vtk.vtkRenderWindow()
renWin.AddRenderer(ren)
iren = vtk.vtkRenderWindowInteractor()
iren.SetRenderWindow(renWin)
iren.SetInteractorStyle(KeyPressInteractorStyle(parent = iren))


#ren.AddActor(actor)
'''
ren.AddActor(actor1)
ren.AddActor(actor2)
ren.AddActor(actor3)
ren.AddActor(actor4)
ren.AddActor(actor5)
ren.AddActor(actor6)
ren.AddActor(actor7)
'''
ren.AddActor(assembly1)
#ren.AddActor(axes)

actor1.SetOrigin(actor1.GetCenter())
actor2.SetOrigin(actor2.GetCenter())
actor3.SetOrigin(actor3.GetCenter())
assembly1.SetOrigin(actor1.GetCenter())

#修改背景颜色
ren.SetBackground(0.1, 0.2, 0.3)
#修改窗口大小
#renWin.SetSize(, )
 
#iren.Initialize()
 
ren.ResetCamera()
ren.GetActiveCamera().Zoom(1.5)
#renWin.Render()
 
#iren.Start()
def q():
    renWin.Render() 
btn=tkinter.Button(top,text="启动",command=q)
btn.place(x=90,y=155)      
tkinter.Label(top, text='坦克操作系统', font=('Arial',8)).place(x=20,y=0)
top.mainloop()