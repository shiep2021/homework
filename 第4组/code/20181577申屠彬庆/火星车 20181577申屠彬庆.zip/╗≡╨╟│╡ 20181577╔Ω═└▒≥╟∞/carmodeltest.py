import vtk
stop_threads = False
class KeyPressInteractorStyle(vtk.vtkInteractorStyleTrackballCamera):
 
    def __init__(self,parent=None):
        self.parent = vtk.vtkRenderWindowInteractor()
        if(parent is not None):
            self.parent = parent
 
        self.AddObserver("KeyPressEvent",self.keyPress)
 
    def keyPress(self,obj,event):
        key = self.parent.GetKeySym()
        speed=0
        if key == 'Up':
            #前进
            
            actor2.RotateY(-0.1)
            actor3.RotateY(-0.1)
            

            #下面这一行是关键，实现了actor的更新
            renderWindow.Render()


        if key == 'Down':
            #后退
            actor2.RotateY(0.1)
            actor3.RotateY(0.1)
            #下面这一行是关键，实现了actor的更新
            renderWindow.Render()




reader1 = vtk.vtkSTLReader()
reader1.SetFileName("carbody.stl")
reader2 = vtk.vtkSTLReader()
reader2.SetFileName("leftwheel.stl")
reader3 = vtk.vtkSTLReader()
reader3.SetFileName("rightwheel.stl")
reader4 = vtk.vtkSTLReader()
reader4.SetFileName("wheel-spindle.stl")
reader5 = vtk.vtkSTLReader()
reader5.SetFileName("camera.stl")
reader6 = vtk.vtkSTLReader()
reader6.SetFileName("camera-spindle.stl")

mapper1 = vtk.vtkPolyDataMapper()
mapper1.SetInputConnection(reader1.GetOutputPort())
mapper2 = vtk.vtkPolyDataMapper()
mapper2.SetInputConnection(reader2.GetOutputPort())
mapper3 = vtk.vtkPolyDataMapper()
mapper3.SetInputConnection(reader3.GetOutputPort())
mapper4 = vtk.vtkPolyDataMapper()
mapper4.SetInputConnection(reader4.GetOutputPort())
mapper5 = vtk.vtkPolyDataMapper()
mapper5.SetInputConnection(reader5.GetOutputPort())
mapper6 = vtk.vtkPolyDataMapper()
mapper6.SetInputConnection(reader6.GetOutputPort())

actor1 = vtk.vtkActor()
actor1.SetMapper(mapper1)
actor2 = vtk.vtkActor()
actor2.SetMapper(mapper2)
actor3 = vtk.vtkActor()
actor3.SetMapper(mapper3)
actor4 = vtk.vtkActor()
actor4.SetMapper(mapper4)
actor5 = vtk.vtkActor()
actor5.SetMapper(mapper5)
actor6 = vtk.vtkActor()
actor6.SetMapper(mapper6)

renderer = vtk.vtkRenderer()
renderWindow = vtk.vtkRenderWindow()
renderWindow.SetWindowName("TESTING")

renderWindow.AddRenderer(renderer)
renderWindowInteractor = vtk.vtkRenderWindowInteractor()
renderWindowInteractor.SetRenderWindow(renderWindow)

renderer.AddActor(actor1)
renderer.AddActor(actor2)
renderer.AddActor(actor3)
renderer.AddActor(actor4)
renderer.AddActor(actor5)
renderer.AddActor(actor6)

renderer.SetBackground(0,0.8,0.8) # Background color white
renderWindow.Render()

actor2.SetOrigin(actor2.GetCenter())
actor3.SetOrigin(actor3.GetCenter())


iren = vtk.vtkRenderWindowInteractor()
iren.SetRenderWindow(renderWindow)
iren.SetInteractorStyle(KeyPressInteractorStyle(parent = iren))
iren.Initialize()
iren.Start()


'''
while True:
    actor2.RotateY(-0.1)
    actor3.RotateY(-0.1)
    renderWindow.Render()
'''